function cnome() {
    let n = document.getElementById("nome").value 
    alert("Bem vindo ao JS: " + n)
}

function ola() {
    console.log("Olá Mundo, e JS2")
    alert("Meu Front-End")
}


ola()

